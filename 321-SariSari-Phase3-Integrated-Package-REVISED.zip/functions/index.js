// 321 Sari-Sari Store — unified ordering backend (TEST LAB PACKAGE)
// Target: sarisari-test-lab ONLY. Do not deploy to production without approval.
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const { initializeApp, getApps } = require("firebase-admin/app");
const { getFirestore, FieldValue } = require("firebase-admin/firestore");
const crypto = require("crypto");
if (!getApps().length) initializeApp();
setGlobalOptions({ region: "asia-southeast1", maxInstances: 5 });
const db = getFirestore();
const OWNER_UID = "lEwOcUJiyKe65BULuaPGLeOS6Il1";
const AREAS = ["San Carlos City Proper","Vallehermoso","Canlaon City","Don Salvador Benedicto (DSB)","Calatrava","Toboso","Store Pickup"];
const TRANSITIONS = {
  New:["Confirmed","Cancelled"], Confirmed:["Preparing","Cancelled"],
  Preparing:["Ready","Cancelled"], Ready:["OutForDelivery","Completed","Cancelled"],
  OutForDelivery:["Completed"], Completed:[], Cancelled:[]
};
const money = n => Math.round((n + Number.EPSILON) * 100) / 100;
function err(code,msg){ throw new HttpsError(code,msg); }
function owner(req){ if(!req.auth || req.auth.uid!==OWNER_UID) err("permission-denied","Authorized Test Lab owner only."); }
function customer(req){ if(!req.auth || req.auth.token?.firebase?.sign_in_provider!=="anonymous") err("unauthenticated","Customer session required."); }
function str(v,max,label){ const s=String(v??"").trim(); if(!s || s.length>max) err("invalid-argument",`Invalid ${label}.`); return s; }

// The browser sends IDs and quantities only. Names, prices and stock are read from Firestore.
exports.placeCustomerOrder = onCall({cors:true}, async req => {
  customer(req);
  const d=req.data||{}, name=str(d.customerName,100,"name"), phone=str(d.phone,30,"phone");
  const area=str(d.deliveryArea,80,"delivery area"), address=String(d.address||"").trim().slice(0,300);
  const payment=String(d.paymentMethod||""), notes=String(d.notes||"").trim().slice(0,500);
  if(name.length<2 || phone.length<7) err("invalid-argument","Name or phone is too short.");
  if(!AREAS.includes(area)) err("invalid-argument","Unsupported delivery area.");
  if(area!=="Store Pickup" && address.length<3) err("invalid-argument","Complete delivery address required.");
  if(!["COD","GCash"].includes(payment)) err("invalid-argument","Choose COD or GCash.");
  if(!Array.isArray(d.items)||d.items.length<1||d.items.length>30) err("invalid-argument","Cart must contain 1–30 products.");
  const qtys=new Map();
  for(const x of d.items){
    const id=String(x?.productId||"").trim(), q=Number(x?.qty);
    if(!id||id.length>150||id.includes("/")||!Number.isSafeInteger(q)||q<1||q>99) err("invalid-argument","Invalid product or quantity.");
    qtys.set(id,(qtys.get(id)||0)+q);
  }
  if(qtys.size>30||[...qtys.values()].some(q=>q>99)) err("invalid-argument","Invalid combined quantities.");
  const requestId=String(d.requestId||"");
  if(!/^[A-Za-z0-9_-]{16,64}$/.test(requestId)) err("invalid-argument","Invalid order request ID.");
  // Bind an idempotency key to the exact normalized checkout payload.
  // A retry with the same key and payload returns the original order;
  // reusing the key after changing the cart/details is rejected.
  const canonicalPayload={
    customerName:name, phone, deliveryArea:area, address, paymentMethod:payment, notes,
    items:[...qtys].sort(([a],[b])=>a.localeCompare(b)).map(([productId,qty])=>({productId,qty}))
  };
  const payloadHash=crypto.createHash("sha256").update(JSON.stringify(canonicalPayload)).digest("hex");
  const uid=req.auth.uid.replace(/[^A-Za-z0-9]/g,"").slice(0,24);
  const orderId=`web_${uid}_${requestId}`, orderRef=db.collection("customerOrders").doc(orderId);
  const products=[...qtys].map(([id,qty])=>({id,qty,ref:db.collection("storeProducts").doc(id)}));
  const itemRefs=products.map(p=>orderRef.collection("items").doc(p.id));
  return db.runTransaction(async tx=>{
    const prior=await tx.get(orderRef);
    if(prior.exists){
      const old=prior.data();
      if(old.createdByUid!==req.auth.uid) err("already-exists","Request ID already used.");
      if(old.requestPayloadHash!==payloadHash) err("already-exists","This checkout request ID belongs to a different order. Please submit again.");
      return {orderId,status:old.status,subtotal:old.subtotal,deliveryFee:old.deliveryFee??null,total:old.total??null,duplicateRetry:true};
    }
    const snaps=await Promise.all(products.map(p=>tx.get(p.ref)));
    const lines=[]; let subtotal=0;
    for(let i=0;i<products.length;i++){
      const p=snaps[i].data()||{}, {id,qty,ref}=products[i];
      if(!snaps[i].exists) err("failed-precondition",`Product ${id} unavailable.`);
      const price=Number(p.price), stock=Number(p.stock), pname=String(p.name||p.productName||p.title||"").trim();
      if(!pname||!Number.isFinite(price)||price<0||!Number.isSafeInteger(stock)||stock<qty||p.active===false)
        err("failed-precondition",`${pname||id}: unavailable or insufficient stock.`);
      const lineTotal=money(price*qty); subtotal=money(subtotal+lineTotal);
      lines.push({productId:id,name:pname,unit:String(p.unit||"pcs"),category:String(p.category||""),qty,price,lineTotal});
    }
    // All transaction reads are complete before any writes.
    for(let i=0;i<products.length;i++) tx.update(products[i].ref,{stock:Number(snaps[i].data().stock)-products[i].qty,updatedAt:FieldValue.serverTimestamp()});
    const fee=area==="Store Pickup"?0:area==="San Carlos City Proper"?30:null;
    const total=fee===null?null:money(subtotal+fee);
    tx.create(orderRef,{
      customerName:name,phone,address,deliveryArea:area,notes,subtotal,deliveryFee:fee,total,grandTotal:total,
      paymentMethod:payment,paymentStatus:payment==="GCash"?"PendingVerification":"Unpaid",
      requestPayloadHash:payloadHash,status:"New",ownerNote:"",source:"online-checkout",createdByUid:req.auth.uid,
      createdAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp(),
      stockDeducted:true,stockRestocked:false,
      itemsText:lines.map(x=>`${x.name} x ${x.qty} ${x.unit} — ₱${x.lineTotal.toFixed(2)}`).join("\n")
    });
    for(let i=0;i<lines.length;i++) tx.create(itemRefs[i],lines[i]);
    return {orderId,status:"New",subtotal,deliveryFee:fee,total,duplicateRetry:false};
  });
});

exports.setCustomerOrderStatus = onCall({cors:true}, async req=>{
  owner(req); const id=str(req.data?.orderId,180,"order ID"), next=String(req.data?.status||"");
  const note=String(req.data?.ownerNote||"").trim().slice(0,300), ref=db.collection("customerOrders").doc(id);
  return db.runTransaction(async tx=>{
    const s=await tx.get(ref); if(!s.exists) err("not-found","Order not found.");
    const o=s.data(), cur=o.status||"New";
    if(!(TRANSITIONS[cur]||[]).includes(next)) err("failed-precondition",`Not allowed: ${cur} → ${next}.`);
    if(next==="Confirmed" && !["Store Pickup","San Carlos City Proper"].includes(o.deliveryArea) && o.deliveryFee==null) err("failed-precondition","Set the negotiated delivery fee before confirming this order.");
    if(next==="Completed" && o.deliveryArea!=="Store Pickup" && cur!=="OutForDelivery") err("failed-precondition","Delivery must be OutForDelivery before completion.");
    if(next==="Completed" && o.paymentMethod==="GCash" && o.paymentStatus!=="Verified") err("failed-precondition","Verify GCash before completion.");
    let itemDocs=[], prodSnaps=[];
    if(next==="Cancelled" && o.stockDeducted===true && o.stockRestocked!==true){
      const is=await tx.get(ref.collection("items")); itemDocs=is.docs;
      const refs=itemDocs.map(x=>db.collection("storeProducts").doc(x.data().productId));
      prodSnaps=await Promise.all(refs.map(x=>tx.get(x)));
      for(let i=0;i<itemDocs.length;i++){
        const q=Number(itemDocs[i].data().qty), st=Number(prodSnaps[i].data()?.stock);
        if(!prodSnaps[i].exists||!Number.isSafeInteger(q)||q<1||!Number.isSafeInteger(st)||st<0) err("failed-precondition","Cannot safely restore stock; no cancellation applied.");
      }
      for(let i=0;i<itemDocs.length;i++) tx.update(db.collection("storeProducts").doc(itemDocs[i].data().productId),{stock:Number(prodSnaps[i].data().stock)+Number(itemDocs[i].data().qty),updatedAt:FieldValue.serverTimestamp()});
      tx.update(ref,{status:next,ownerNote:note,stockRestocked:true,cancelledAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
    } else {
      tx.update(ref,{status:next,ownerNote:note,updatedAt:FieldValue.serverTimestamp(),...(next==="Completed"&&o.paymentMethod==="COD"?{paymentStatus:"PaidCOD",paidAt:FieldValue.serverTimestamp()}:{})});
    }
    return {orderId:id,status:next};
  });
});

exports.verifyCustomerGcashPayment = onCall({cors:true},async req=>{
  owner(req); const id=str(req.data?.orderId,180,"order ID"), reference=str(req.data?.reference,60,"GCash reference");
  if(reference.length<6) err("invalid-argument","GCash reference is too short.");
  const ref=db.collection("customerOrders").doc(id);
  return db.runTransaction(async tx=>{
    const s=await tx.get(ref); if(!s.exists) err("not-found","Order not found.");
    const o=s.data();
    if(o.paymentMethod!=="GCash"||["Cancelled","Completed"].includes(o.status)) err("failed-precondition","Order cannot be verified.");
    if(o.paymentStatus==="Verified") err("already-exists","Already verified.");
    tx.update(ref,{paymentStatus:"Verified",gcashReference:reference,paymentVerifiedBy:req.auth.uid,paymentVerifiedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
    return {orderId:id,paymentStatus:"Verified"};
  });
});

exports.setCustomerOrderDeliveryFee = onCall({cors:true},async req=>{
  owner(req); const id=str(req.data?.orderId,180,"order ID"), fee=Number(req.data?.deliveryFee);
  if(!Number.isFinite(fee)||fee<0||fee>5000) err("invalid-argument","Invalid fee.");
  const ref=db.collection("customerOrders").doc(id);
  return db.runTransaction(async tx=>{
    const s=await tx.get(ref); if(!s.exists) err("not-found","Order not found.");
    const o=s.data();
    if(["Store Pickup","San Carlos City Proper"].includes(o.deliveryArea)||["Cancelled","Completed","OutForDelivery"].includes(o.status)) err("failed-precondition","Fee cannot be changed for this order.");
    const total=money(Number(o.subtotal)+fee);
    tx.update(ref,{deliveryFee:fee,total,grandTotal:total,deliveryFeeSetBy:req.auth.uid,deliveryFeeSetAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp()});
    return {orderId:id,deliveryFee:fee,total};
  });
});
