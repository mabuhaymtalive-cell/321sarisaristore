const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const customer = fs.readFileSync(path.join(root, 'customer-ordering.html'), 'utf8');
const owner = fs.readFileSync(path.join(root, 'owner-order-inbox.html'), 'utf8');
const backend = fs.readFileSync(path.join(root, 'functions', 'index.js'), 'utf8');
const rules = fs.readFileSync(path.join(root, 'firestore.rules.test-lab'), 'utf8');

test('customer and owner pages target Test Lab only', () => {
  for (const html of [customer, owner]) {
    assert.match(html, /projectId:\s*"sarisari-test-lab"/);
    assert.doesNotMatch(html, /projectId:\s*"sarisaristore321-1f24b"/);
    assert.match(html, /asia-southeast1/);
  }
});

test('customer checkout uses stable retry key for identical payload', () => {
  assert.match(customer, /crypto\.subtle\.digest\("SHA-256"/);
  assert.match(customer, /localStorage\.getItem\(storageKey\)/);
  assert.match(customer, /localStorage\.setItem\(storageKey,requestId\)/);
  assert.match(customer, /localStorage\.removeItem\(storageKey\)/);
  assert.match(backend, /requestPayloadHash/);
  assert.match(backend, /duplicateRetry:true/);
});

test('backend enforces atomic stock deduction and owner-only actions', () => {
  assert.match(backend, /db\.runTransaction/);
  assert.match(backend, /tx\.update\(products\[i\]\.ref,\{stock:/);
  assert.match(backend, /function owner\(req\)/);
  assert.match(backend, /function customer\(req\)/);
  assert.match(backend, /exports\.setCustomerOrderStatus/);
  assert.match(backend, /exports\.verifyCustomerGcashPayment/);
  assert.match(backend, /exports\.setCustomerOrderDeliveryFee/);
});

test('rules block direct client writes to orders and inventory', () => {
  assert.match(rules, /allow create, update, delete: if false/);
  assert.match(rules, /match \/storeProducts/);
  assert.match(rules, /allow read, write: if isOwner\(\)/);
  assert.match(rules, /match \/\{document=\*\*\}/);
});

test('owner inbox has all callable workflow handlers', () => {
  assert.match(owner, /httpsCallable\(fn,"setCustomerOrderStatus"\)/);
  assert.match(owner, /httpsCallable\(fn,"verifyCustomerGcashPayment"\)/);
  assert.match(owner, /httpsCallable\(fn,"setCustomerOrderDeliveryFee"\)/);
  for (const id of ['login','inbox','refresh','logout','orders','inboxMsg'])
    assert.match(owner, new RegExp(`id="${id}"`));
});
