321 SARI-SARI STORE — PHASE 3 ORDERING SYSTEM
Prepared integration package for branch: customer-ordering-tablet-test
Firebase target in the HTML and Functions: sarisari-test-lab ONLY

FILES AND DESTINATIONS
customer-ordering.html       -> repository root
owner-order-inbox.html       -> repository root
firebase.json                -> repository root (Functions source = functions)
firestore.rules.test-lab     -> review-only Test Lab rules file; NOT named firestore.rules
functions/index.js           -> functions/index.js
functions/package.json       -> functions/package.json

WHAT IS INCLUDED
- Customer catalog, cart, and checkout page.
- Owner order inbox with status, GCash manual-verification, and negotiated-fee actions.
- Callable backend for order creation, atomic stock deduction, idempotent request retry,
  owner-controlled status transitions, cancellation stock restoration, manual GCash marking,
  and negotiated delivery fees.
- Test Lab-only Firestore rules draft that blocks browser-side order and stock writes.

DATA CONTRACT
Customer catalog reads active documents from publicCatalog/{productId}.
The publicCatalog document ID must match storeProducts document ID.
The server treats storeProducts as authoritative and expects name (or productName/title),
number price, integer stock, and optional unit/category/active fields.

IMPORTANT SAFETY
- This is a TEST LAB candidate only. Firebase project ID is sarisari-test-lab.
- Do not deploy or copy these settings/rules to production project sarisaristore321-1f24b.
- Do not overwrite the production dashboard, production Rules, or production inventory.
- Do not deploy firestore.rules.test-lab automatically. It is a separate review file.
- The included firebase.json only declares Functions source. Merge with the branch's existing
  firebase.json if it later contains other required hosting/emulator configuration.
- The current backend uses Test Lab owner UID lEwOcUJiyKe65BULuaPGLeOS6Il1.
- GCash is not verified by an API. The owner must independently check the actual GCash receipt
  and only then use the manual verification action.
- No Messenger/SMS/WhatsApp sending is included.
- App Check, rate limiting/abuse protection, emulator security tests, catalog mapping, and a
  controlled Test Lab end-to-end smoke test remain required before calling Phase 3 complete.

UPLOAD GUIDE (TABLET)
1. Extract this ZIP on the tablet.
2. In GitHub, stay on customer-ordering-tablet-test (never main).
3. Upload the two HTML files to the repository root.
4. Upload functions/index.js and functions/package.json keeping the functions folder.
5. Keep firestore.rules.test-lab as a review-only file; do not publish it.
6. Compare firebase.json with the existing root file before replacing it; this package's
   Functions configuration matches the current branch's simple functions-source config.
7. Do not deploy Firebase yet. Have the files reviewed and tested in Test Lab first.
