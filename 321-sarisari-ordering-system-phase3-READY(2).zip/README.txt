321 SARI-SARI STORE — ORDERING PHASE 3 INTEGRATION PACKAGE
Target project: sarisari-test-lab ONLY
This package is a prepared integration candidate, NOT deployed.

CONTENTS
- customer-ordering.html: public active catalog, cart, checkout via callable Function
- owner-order-inbox.html: owner inbox; lifecycle/payment/fee changes via callable Functions
- functions/index.js: server-authoritative order creation, atomic stock deduction, idempotent retry,
  cancellation stock restoration, controlled status changes, manual GCash verification, negotiated fee
- firestore.rules.test-lab: deny all client order writes; owner-only order reads; public active catalog reads
- firebase.json and functions/package.json

IMPORTANT DATA CONTRACT
Customer catalog is read from publicCatalog/{productId}. Order submission validates and reads the matching
storeProducts/{productId} document on the server; its name, price, unit, category and integer stock are
authoritative. Catalog document IDs MUST match storeProducts document IDs. Store product documents need
name (or productName/title), numeric price, integer stock, optional unit/category and optional active != false.
Do not publish a catalog item unless its corresponding storeProducts document exists and is sellable.

SECURITY / OPERATIONS
- Customer browser never writes orders or inventory. Callable Function uses a Firestore transaction.
- Stock is deducted atomically when order is created. Repeated request IDs return the same order.
- Owner actions are callable Functions and restricted to the configured Test Lab owner UID.
- Cancellation restores stock once, only before delivery; status transitions are constrained.
- GCash is NOT automatically verified. Owner must compare the transaction in the actual GCash account,
  then enter its reference in the owner inbox.
- Other delivery areas show a pending/negotiable fee. Owner sets fee before confirming final total.
- San Carlos City Proper fee = PHP 30; Store Pickup = PHP 0.
- This package does not send Messenger/SMS/WhatsApp messages. It shows customer order reference and contact details.
- No production Firebase config is included. Do not change production Rules/data or deploy to production.
- Review required: Firebase callable Functions deployment, indexes if prompted, App Check/rate limits,
  authentication, catalog field mapping, and a controlled Test Lab smoke run before any real-store release.
