# 321 Sari-Sari Store — Test Lab ordering integration

**Target Firebase project:** `sarisari-test-lab`  
**NOT production. Do not copy these rules to `sarisaristore321-1f24b`.**

## Included files

- `customer-ordering.html` — anonymous customer checkout; one fixed sample product.
- `owner-order-inbox.html` — Test Lab owner login, reads order parent + `items` subcollection, updates owner status/note.
- `firestore.rules` — subcollection-format Test Lab rules draft.
- `firebase.json` — maps Firestore rules to `firestore.rules`; preserves the existing Functions source and declares local emulator ports.
- `.firebaserc` — default project deliberately set to `sarisari-test-lab`.
- `test-lab-publicCatalog-seed.json` — required sample document data.

## Data contract

Customer checkout creates both documents in one Firestore batch:

- `customerOrders/{orderId}`
- `customerOrders/{orderId}/items/1`

The item line references `p_1793230199357`. The Rules require this catalog document to exist:

- `publicCatalog/p_1793230199357`
- `active: true`
- `inStock: true`

Create that document manually in the **sarisari-test-lab** Firestore console using the JSON in `test-lab-publicCatalog-seed.json`. Do not create it in production.

## Owner authentication requirement

The owner inbox permits only UID `lEwOcUJiyKe65BULuaPGLeOS6Il1`. The corresponding email/password account must exist in **sarisari-test-lab** Authentication and must have that exact UID. Do not enter production credentials into the Test Lab page.

## Current limitations

- This is a one-product prototype, not the live catalog.
- No stock deduction, GCash verification, payment collection, delivery dispatch, or Messenger/SMS/WhatsApp sending.
- The Rules are a review draft and have **not** been emulator-tested or published.
- Do not deploy rules or merge this branch into `main` until the Emulator tests and owner approval are complete.
- GitHub Pages can host the HTML files, but Firebase Rules are not deployed by GitHub Pages.
