import { readFileSync } from 'node:fs';
import { beforeAll, afterAll, beforeEach, describe, expect, it } from 'vitest';
import {
  initializeTestEnvironment,
  assertSucceeds,
  assertFails
} from '@firebase/rules-unit-testing';
import {
  collection,
  doc,
  getDoc,
  getDocs,
  serverTimestamp,
  setDoc,
  updateDoc,
  writeBatch
} from 'firebase/firestore';

const PROJECT_ID = 'sarisari-test-lab';
const OWNER_UID = 'lEwOcUJiyKe65BULuaPGLeOS6Il1';
const PRODUCT_ID = 'p_1793230199357';
let testEnv;

beforeAll(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: { rules: readFileSync('firestore.rules', 'utf8') }
  });
});

afterAll(async () => {
  await testEnv?.cleanup();
});

beforeEach(async () => {
  await testEnv.clearFirestore();
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await setDoc(doc(ctx.firestore(), 'publicCatalog', PRODUCT_ID), {
      active: true,
      inStock: true,
      name: 'Test Product',
      price: 10
    });
  });
});

function parentData(overrides = {}) {
  return {
    customerName: 'Test Customer',
    phone: '09123456789',
    deliveryArea: 'San Carlos City Proper',
    address: '123 Test Street',
    paymentMethod: 'COD',
    notes: '',
    source: 'spark-customer-web',
    createdAt: serverTimestamp(),
    ...overrides
  };
}

function itemData(overrides = {}) {
  return {
    productId: PRODUCT_ID,
    qty: 2,
    createdAt: serverTimestamp(),
    ...overrides
  };
}

async function submitAtomicOrder(db, id, parentOverrides = {}, itemOverrides = {}) {
  const batch = writeBatch(db);
  batch.set(doc(db, 'customerOrders', id), parentData(parentOverrides));
  batch.set(doc(db, 'customerOrders', id, 'items', '1'), itemData(itemOverrides));
  await batch.commit();
}

describe('321 Test Lab Firestore rules — parent + items subcollection', () => {
  it('allows anonymous customer to create parent and items/1 in one atomic batch', async () => {
    const db = testEnv.authenticatedContext('anonymous-customer-1', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertSucceeds(submitAtomicOrder(db, 'valid-order-1'));
  });

  it('rejects parent document created without items/1', async () => {
    const db = testEnv.authenticatedContext('anonymous-customer-2', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertFails(setDoc(doc(db, 'customerOrders', 'parent-only'), parentData()));
  });

  it('rejects item line created without its parent in the same batch', async () => {
    const db = testEnv.authenticatedContext('anonymous-customer-3', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertFails(setDoc(doc(db, 'customerOrders', 'item-only', 'items', '1'), itemData()));
  });

  it('rejects unsupported product IDs and quantities outside 1–99', async () => {
    const db = testEnv.authenticatedContext('anonymous-customer-4', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertFails(submitAtomicOrder(db, 'bad-product', {}, { productId: 'other-product' }));
    await assertFails(submitAtomicOrder(db, 'zero-qty', {}, { qty: 0 }));
    await assertFails(submitAtomicOrder(db, 'too-many', {}, { qty: 100 }));
  });

  it('rejects unsupported delivery area and payment method', async () => {
    const db = testEnv.authenticatedContext('anonymous-customer-5', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertFails(submitAtomicOrder(db, 'bad-area', { deliveryArea: 'Outside Test Area' }));
    await assertFails(submitAtomicOrder(db, 'bad-payment', { paymentMethod: 'Bank Transfer' }));
  });

  it('rejects unauthenticated writes and anonymous reads of private orders', async () => {
    const unauthDb = testEnv.unauthenticatedContext().firestore();
    await assertFails(setDoc(doc(unauthDb, 'customerOrders', 'no-auth'), parentData()));

    const customerDb = testEnv.authenticatedContext('anonymous-customer-6', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertSucceeds(submitAtomicOrder(customerDb, 'private-order'));
    await assertFails(getDoc(doc(customerDb, 'customerOrders', 'private-order')));
    await assertFails(getDocs(collection(customerDb, 'customerOrders')));
  });

  it('allows only the configured Test Lab owner to read and update orders', async () => {
    const customerDb = testEnv.authenticatedContext('anonymous-customer-7', {
      firebase: { sign_in_provider: 'anonymous' }
    }).firestore();
    await assertSucceeds(submitAtomicOrder(customerDb, 'owner-visible-order'));

    const ownerDb = testEnv.authenticatedContext(OWNER_UID).firestore();
    await assertSucceeds(getDoc(doc(ownerDb, 'customerOrders', 'owner-visible-order')));
    await assertSucceeds(getDocs(collection(ownerDb, 'customerOrders')));
    await assertSucceeds(updateDoc(doc(ownerDb, 'customerOrders', 'owner-visible-order'), {
      ownerStatus: 'Confirmed',
      ownerNote: 'Test update'
    }));

    const otherOwnerDb = testEnv.authenticatedContext('not-the-owner').firestore();
    await assertFails(getDoc(doc(otherOwnerDb, 'customerOrders', 'owner-visible-order')));
  });

  it('denies access to unrelated collections', async () => {
    const ownerDb = testEnv.authenticatedContext(OWNER_UID).firestore();
    await assertFails(setDoc(doc(ownerDb, 'privateData', 'blocked'), { value: true }));
  });
});
